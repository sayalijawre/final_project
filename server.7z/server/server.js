const express = require('express')
const app = express()
var parser = require('body-parser')
const session=require('express-session')

//const Dao = require('./modules/data-access/data-access')
const UserManagement = require('./modules/userManagement/user_management')
const OrganizationManagement = require('./modules/organizationManagement/organization_management')
const Session=require('./modules/userManagement/session')
//const dao = new Dao()
const user = new UserManagement()
const orgs = new OrganizationManagement()
const sessManager = new Session()

app.use(session(sessManager.init()))
/*********************user signup***********************/
app.get('/rest/api/users/get/', async (req, res) => {
    let result = await user.findAll();
    res.send(result)
})
app.use(parser.json());
//method on clicking signUp 
app.post('/rest/api/users/add', async (req, res) => {
    let authData = await user.authInsert(req.body);
    let result = await user.signupInsert(req.body);  
    let verifyUser = await user.verifyInsert(req.body);
    let verficationData = await user.findVerificationData(req.body);
    res.send(verficationData);
})
//unique username check
app.post('/rest/api/users/uniqueUserName', async (req, res) => {
    let isUnique = await user.uniqueUserName(req.body);
    res.send(isUnique);
})

//unique email check
app.post('/rest/api/users/uniqueEmail', async (req, res) => {
    let isUnique = await user.uniqueEmail(req.body);
    res.send(isUnique);
})

//after activating the link
app.delete('/rest/api/users/activate/:userName/:link', async (req, res) => {
    let result = await user.deleteVerifiedUser(req.params)
    res.send(result)
})

//updated link for verification
app.patch('/rest/api/users/updateVerificationLink', async (req, res) => {
    let result= await user.updateVerifyLink(req.body)
    res.send(result)
})

/*********************organization signup***********************/
app.get('/rest/api/orgs/get/', async (req, res) => {
    let result = await orgs.findAll();
    res.send(result)
})
app.use(parser.json());
//method on clicking signUp 
app.post('/rest/api/orgs/add', async (req, res) => {
    let authData = await orgs.authInsert(req.body);
    let result = await orgs.signupInsert(req.body);  
    let verifyUser = await orgs.verifyInsert(req.body);
    let verficationData = await orgs.findVerificationData(req.body);
    res.send(verficationData)
})

//unique company ID check
app.post('/rest/api/orgs/uniqueCompanyID', async (req, res) => {
    let isUnique = await orgs.uniqueCompanyID(req.body);
    res.send(isUnique);
})

//unique email check
app.post('/rest/api/orgs/uniqueEmail', async (req, res) => {
    let isUnique = await orgs.uniqueEmail(req.body);
    res.send(isUnique);
})


//after activating the link
app.delete('/rest/api/orgs/activate/:companyID/:link', async (req, res) => {
    let result = await orgs.deleteVerifiedUser(req.params)
    res.send(result)
})

//updated link for verification
app.patch('/rest/api/orgs/updateVerificationLink', async (req, res) => {
    let result= await orgs.updateVerifyLink(req.body)
    res.send(result)
})



/*********************login***********************/
/*********************users**********************/
//method on clicking loginIn
app.post('/rest/api/users/signin',async(req,res)=>{
    let result = await user.signin(req.body);
    res.send(result);
})
//method on clicking forgot password
app.post('/rest/api/users/password', async (req, res) => {
let result = await user.forgotPassword(req.body);
console.log(result);
})
//method to update new Password
 app.post('/rest/api/users/changepassword', async (req, res) => {
     let result = await user.changePassword(req.body);
     console.log(result);
 })

 /****************************org**************************/
 //method on clicking loginIn
app.post('/rest/api/orgs/signin',async(req,res)=>{
    let result = await orgs.signin(req.body);
    res.send(result);
})
//method on clicking forgot password
app.post('/rest/api/orgs/password', async (req, res) => {
let result = await orgs.forgotPassword(req.body);
console.log(result);
})
//method to update new Password
 app.post('/rest/api/orgs/changepassword', async (req, res) => {
     let result = await orgs.changePassword(req.body);
     console.log(result);
 })

app.listen('8080', () => console.log('Listening on port 8080'))