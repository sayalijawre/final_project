DefalutObj = 
    {
        isVerified: false,
        isDeleted: false,
        profile: {
            locations: [],
            followers: [],
            post: [ ],
            jobs: [ ]
        }

    }

module.exports = DefalutObj;