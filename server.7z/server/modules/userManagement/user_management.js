const Dao = require('../data-access/data-access')
const Utils = require('./utils')
const DefaultObj = require('./schema');
//const Schema = require('./schema');
const dao = new Dao()
const utils = new Utils()
var email;
//const schema = new Schema();
//creating userManagement to export in server.js
class userManagement {
//fetching all user data
    async findAll(){
         let resultFindAll = await dao.find("users");
         return resultFindAll;
    }

//inserting details into database from signUp form
    async signupInsert(req) {
        let obj = req;
        let date = new Date(obj.dateOfBirth);
        obj.dateOfBirth = date;
        delete obj.password;
        obj = {
            ...obj,
            ...DefaultObj
        }
        let result;
        
        try {
            result = await dao.insert("users", obj);
        }
        catch (err) {
            result = { error: err };
        }
        return result;
    }
    //inserting email and password into authUsers collection
    async authInsert(req) {
        let hashPassword=utils.encryptPassword(req.password)
        let obj = { email: req.email, password: hashPassword };
        console.log(hashPassword)
        let result
        try {
            result = await dao.insert("authUsers", obj);
        }
        catch (err) {
            result = { error: err };
        }
        return result;
    }

    //verification insertion
    async verifyInsert(req)
    {
        let link=utils.generateVerificationLink();
        console.log(link)
        let obj={verificationCode:link,userName:req.userName};
        let result;
        try{
            result=await dao.insert("verifications",obj);
        }
        catch(err){
            result = { error: err };
        }
        return result;
    }

    //fetching verification data of user
    async findVerificationData(userObj){
        let userFind=await dao.find('verifications',{userName: userObj.userName})
        console.log(userFind);
        return userFind;
    }

    //unique user Name checking 
   async uniqueUserName(userObj){
       console.log(userObj.userName);
        let userFind=await dao.find('users',{userName: userObj.userName})
        console.log(userFind)
        if(userFind.length==1)
        {
            return "notunique"
        }
        else
        {
            return "unique"
        }
   }

      //unique user email checking 
   async uniqueEmail(userObj){
       console.log(userObj.email);
        let emailFind=await dao.find('users',{email: userObj.email})
        console.log(emailFind)
        if(emailFind.length==1)
        {
            return "notunique"
        }
        else
        {
            return "unique"
        }
   }

    // Deleting verified users in the Verifications 
    async deleteVerifiedUser(req){
        let userFind=await dao.find('verifications',{userName: req.userName})
        if(userFind.length==1)
        {
            if(userFind[0].userName===req.userName && userFind[0].verificationCode===req.link)
        {
         let verifyUpdate = await dao.update('users',{userName: req.userName},{$set:{isVerified: true}})
         let result = await dao.delete("verifications", { userName: req.userName })
         return verifyUpdate;

        }}
        else
        {
            return "Account already verified!!!"
        }
    
    
        
             }

    async updateVerifyLink(req){
    let result
    let link=utils.generateVerificationLink();
        link=link+'/'+req.userName;
    try {
        result = await dao.update("verifications",{userName: req.userName},{$set:{verificatonLink: link}})
    } 
    catch (err) {
        result = {err:err}
    }
}
/*****************************************login*************************************** */

    //verification for login
    async signin(req) {
        let log = await dao.find("users", { userName: req.userName })
        if (log.length == 1) {
            if (log[0].isDeleted == false) {
                let result = await dao.find("authUsers", { email: log[0].email })
                 let hashPassword=utils.encryptPassword(req.password)
                if (result[0].password == hashPassword) {
                    if (log[0].isVerified == true) {
                        return "logged In";
                    }
                    else {
                        return "account logged In with not verified";
                    }

                }
                else {
                    return "Incorrect Password";
                }
            }
            else {
                return "Account deleted";
            }
        }

        else {
            return "Username not found";
        }
    }
    //forgot password verification link
    async forgotPassword(req) {
        let result = await dao.find("users", { userName: req.userName })
         if (result.length == 1) {
    if (result[0].userName== req.userName)
    {
        this.email=result[0].email;
        let link=utils.generateVerificationLink();
        let obj={verificationCode:link,userName:req.userName};
        try{
            result=await dao.insert("pwdchangever",obj);
        }
        catch(err){
            result = { error: err };
        }
        return result;
    }
    else{
         return("username not found");
    }
         }
}
//change password
async changePassword(req) {
    let hashPassword=utils.encryptPassword(req.password)
    let result = await dao.update("authUsers", { email: this.email },{$set:{password:hashPassword}});
         let log = await dao.delete("pwdchangever", { userName: req.userName})
    return ("update done");
}
}

module.exports = userManagement;